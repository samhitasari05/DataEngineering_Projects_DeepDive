#!/bin/bash
dbt deps --profiles-dir .
dbt debug --profiles-dir .
dbt build --profiles-dir .