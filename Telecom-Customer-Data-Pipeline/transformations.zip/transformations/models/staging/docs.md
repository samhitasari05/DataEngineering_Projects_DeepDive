{% docs churn_source %}

 This is the replica of the Postgres Data.

{% enddocs %}

{% docs population_table %}

Records of the population per zipcode.

{% enddocs %}

{% docs population_col %}

Population in any given zip code.

{% enddocs %}

{% docs zipcode_col %}

Zip code of the area.

{% enddocs %}

{% docs customer_table %}

Customer details.

{% enddocs %}